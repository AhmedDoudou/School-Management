from payments.models import Payment, PaymentIntent
from django.contrib import admin

admin.site.register(Payment)
admin.site.register(PaymentIntent)
