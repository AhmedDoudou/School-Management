<?php
	
function tpc_child_scripts() {
	wp_enqueue_style( 'tpc-parent-style', get_template_directory_uri(). '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'tpc_child_scripts' );

/**
 * ==== Your code here. ===== */
