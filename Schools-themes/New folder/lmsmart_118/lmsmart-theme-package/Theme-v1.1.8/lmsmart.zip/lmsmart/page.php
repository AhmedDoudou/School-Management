<?php

defined('ABSPATH') || exit;

use LMSMart_Theme_Helper as LMSMart;

/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package lmsmart
 * @since 1.0.0
 */

get_header();
the_post();

$sb = LMSMart::get_sidebar_data();
$row_class = $sb['row_class'] ?? '';
$column = $sb['column'] ?? '';
$container_class = $sb['container_class'] ?? '';

// Render
echo '<div class="tpc-container', apply_filters('lmsmart/container/class', esc_attr( $container_class )), '">';
echo '<div class="row ', apply_filters('lmsmart/row/class', esc_attr( $row_class )), '">';

    echo '<div id="main-content" class="tpc_col-', apply_filters('lmsmart/column/class', esc_attr( $column )), '">';

        the_content(esc_html__('Read more!', 'lmsmart'));

        // Pagination
        wp_link_pages(LMSMart::pagination_wrapper());

        // Comments
        if (comments_open() || get_comments_number()) {
            comments_template();
        }

    echo '</div>';

    if ($sb) {
        LMSMart::render_sidebar($sb);
    }

echo '</div>';
echo '</div>';

get_footer();
