<?php
/**
 * @author  ThimPress
 * @package LearnPress/Templates
 * @version 4.0.1
 */
 if (class_exists('RWMB_Loader')) {
 	$lp_intro_video = rwmb_meta('lp_intro_video');
}

defined( 'ABSPATH' ) || exit;
?>

<div class="course-sidebar-preview">
	<div class="media-preview">
		
	<div class="tpc-video_popup with_image">
		<div class="videobox_content">

			<div class="videobox_background">
				<?php
				LP()->template( 'course' )->course_media_preview();
				learn_press_get_template( 'loop/course/badge-featured' );
				?>
			</div>
			<?php  if (class_exists('RWMB_Loader') && !empty($lp_intro_video)) { ?>
			<div class="videobox_link_wrapper">

				<div class="videobox_link " data-lity="" href="<?php echo esc_url( $lp_intro_video ); ?>">
					<svg class="videobox_icon" width="33%" height="33%" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"></path>
					</svg>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>

	</div>

	<?php
	// Price box.
	LP()->template( 'course' )->course_pricing();

	// Graduation.
	LP()->template( 'course' )->course_graduation();

	// Buttons.
	LP()->template( 'course' )->course_buttons();

	LP()->template( 'course' )->user_time();

	LP()->template( 'course' )->user_progress();
	?>
</div>
