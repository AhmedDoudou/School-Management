<?php


    /**
     * Enable override template
     */
    add_filter( 'learn-press/override-templates', '__return_true' );

    /**
     * Add removed action
     */
    remove_action( 'learn-press/before-courses-loop', LP()->template( 'course' )->func( 'courses_top_bar' ), 10 );

    /**
     * Custom Course features
     */
    add_action('learn-press/after-course-summary-sidebar', 'lmsmart_learnpress_course_meata', 1);
    function lmsmart_learnpress_course_meata(){ 

    $course = LP_Global::course();
    $learnpress_single_hide_instructor = LMSMart_Theme_Helper::get_mb_option('learnpress_single_hide_instructor');
    $learnpress_single_hide_level = LMSMart_Theme_Helper::get_mb_option('learnpress_single_hide_level');
    $learnpress_single_hide_duration = LMSMart_Theme_Helper::get_mb_option('learnpress_single_hide_duration');
    $learnpress_single_hide_enrolled = LMSMart_Theme_Helper::get_mb_option('learnpress_single_hide_enrolled');
    $learnpress_single_hide_lesson = LMSMart_Theme_Helper::get_mb_option('learnpress_single_hide_lesson');
    $learnpress_single_hide_category = LMSMart_Theme_Helper::get_mb_option('learnpress_single_hide_category');

    
    ?>
    <div class="learnpress-single-course-meta learnpress-meta-top">
        <?php if( !$learnpress_single_hide_duration ){ ?>
           <div class="learnpress-course-duration">
            <span class="meta-label">
                <i class="meta-icon flaticon-wall-clock"></i>
                <?php esc_html_e( 'Duration', 'lmsmart' ); ?>
            </span>
             <?php echo learn_press_get_post_translated_duration( get_the_ID(), esc_html__( 'Lifetime access', 'lmsmart' ) ); ?>
           </div>
        <?php } ?>
        <?php if( !$learnpress_single_hide_lesson){ ?> 
           <div class="learnpress-course-lesson-count">
                <span class="meta-label">
                    <i class="meta-icon flaticon-google-docs"></i>
                    <?php esc_html_e( 'Lesson', 'lmsmart' ); ?> 
                </span>
              <div class="meta-value">
                <?php
                    $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
                    $lessons_text = ('1' == $lessons) ? esc_html__(' Lesson', 'lmsmart') : esc_html__(' Lessons', 'lmsmart');
                    echo esc_attr( $lessons ) . $lessons_text;
                ?>     
              </div>
           </div>
        <?php } ?>
        <?php if( !$learnpress_single_hide_enrolled){ ?> 
           <div class="learnpress-course-lesson-count">
                <span class="meta-label">
                    <i class="meta-icon flaticon-shopping-cart-1"></i>
                    <?php esc_html_e( 'Enrolled', 'lmsmart' ); ?>
                </span>
              <div class="meta-value">
                    <?php   
                        $students = (int)learn_press_get_course()->count_students();
                        $students_text = ('1' == $students) ? esc_html__(' Student', 'lmsmart') : esc_html__(' Students', 'lmsmart');

                        echo esc_attr( $students ) . $students_text;
                     ?>
              </div>
           </div>
        <?php } ?>

        <?php if(!$learnpress_single_hide_instructor){ ?>
           <div class="learnpress-course-level">
                <span class="meta-label">
                    <i class="meta-icon flaticon-user-1"></i>
                    <?php esc_html_e( 'Instructor', 'lmsmart' ); ?> 
                </span>

              <div class="meta-value">  
                <?php echo get_the_author(); ?>  
            </div>
           </div>
        <?php } ?>

        <?php if( !$learnpress_single_hide_level ){ ?>
           <div class="learnpress-course-level">
              <span class="meta-label">
               <i class="meta-icon flaticon-bar-chart-1"></i>
                <?php esc_html_e( 'Level', 'lmsmart' ); ?>          
            </span>
            <?php $level = learn_press_get_post_level( get_the_ID() ); ?>
              <div class="meta-value"> <?php echo esc_html( $level ); ?></div>
           </div>
        <?php } ?>

    <?php if( !$learnpress_single_hide_category ): ?>
      
       <div class="learnpress-course-categories">

            <span class="meta-label">
                <i class="meta-icon flaticon-price-tag"></i>
                <?php esc_html_e( 'Category', 'lmsmart' ); ?>        
            </span>

          <div class="meta-value">
            <?php
                if ( ! get_the_terms( get_the_ID(), 'course_category' ) ) {
                    esc_html_e( 'Uncategorized', 'lmsmart' );
                } else {
                    echo get_the_term_list( get_the_ID(), 'course_category', '');
                }
            ?>  
          </div>
       </div>
    <?php endif ?>

    </div>

    <?php
    }
// Fix learnpress archive page pagination 
add_action( 'pre_get_posts', 'lmsmart_cpt_archive_items' );
function lmsmart_cpt_archive_items( $query ) {
if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'lp_course' ) ) {
        $query->set( 'posts_per_page', '8' );
    }

}



    