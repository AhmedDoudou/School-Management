<?php
/**
 * Template for displaying primary course meta data such as: Instructor, Categories, Reviews (addons)...
 *
 * @author  ThimPress
 * @package LearnPress/Templates
 * @version 4.0.0
 */

defined( 'ABSPATH' ) or die;
$course = LP_Global::course();


if ( ! $course ) {
    return;
}
if ( class_exists('LP_Addon_Course_Review_Preload')) {


$course_id       = get_the_ID();
$course_rate_res = learn_press_get_course_rate( $course_id, false );
$course_rate     = $course_rate_res['rated'];
$total           = $course_rate_res['total'];

?>

<div class="course-featured-review">
    
    <div class="featured-review__stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <span class="lmsmart-course-rate__summary-value"> <?php echo esc_attr( '(' ); ?><?php echo number_format( $course_rate, 1 ); ?><?php echo esc_attr( ')' ); ?></span>   
    </div>
     
</div>

<?php } ?>