<?php
/**
 * Template for displaying course content within the loop.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/content-course.php
 *
 * @author  ThimPress
 * @package LearnPress/Templates
 * @version 4.0.0
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();

$learnpress_archive_layout = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_layout');
$lp_archive_hide_enroll_btn = LMSMart_Theme_Helper::get_mb_option('lp_archive_hide_enroll_btn');
$lp_archive_enroll_btn_switch = LMSMart_Theme_Helper::get_mb_option('lp_archive_enroll_btn_switch');
$lp_see_more_text = LMSMart_Theme_Helper::get_mb_option('lp_see_more_text');
$learnpress_archive_hide_media = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_media');
$learnpress_archive_hide_categories = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_categories');
$learnpress_archive_hide_price = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_price');
$learnpress_archive_hide_title = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_title');
$learnpress_archive_hide_instructor = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_instructor');
$learnpress_archive_hide_students = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_students');
$learnpress_archive_hide_lessons = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_lessons');
$learnpress_archive_hide_reviews = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_reviews');
$lp_archive_hide_enroll_btn = LMSMart_Theme_Helper::get_mb_option('lp_archive_hide_enroll_btn');
$lp_archive_enroll_btn_switch = LMSMart_Theme_Helper::get_mb_option('lp_archive_enroll_btn_switch');
$learnpress_archive_hide_excerpt_content = LMSMart_Theme_Helper::get_mb_option('learnpress_archive_hide_excerpt_content');

$learnpress_tf_hover_popup_type = LMSMart_Theme_Helper::get_mb_option('learnpress_tf_hover_popup_type');


if (class_exists('LearnPress')) {
?>
<?php if ($learnpress_archive_layout == '3'): ?>


<article class="tpc-course">
	<?php  if ($learnpress_tf_hover_popup_type == 'show_content_popup') : ?>
		<div class="course__popup-wrap">

			<?php if (!$learnpress_archive_hide_instructor): ?>
		        <div class="tpc-course-author-name">
		            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
		            <?php echo get_the_author(); ?>
		        </div>
			<?php endif; ?>

			  <div class="courses-content">

				<div class="course__top-meta">
					 <?php if (!$learnpress_archive_hide_categories): ?>
						<div class="course__categories ">
							<?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
						</div>
					 <?php endif; ?>
					 <div class="price">
					 	  <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
					 </div>
				</div>

				<?php if (!$learnpress_archive_hide_title): ?>
				<h4 class="course__title">
					<a href="<?php the_permalink(); ?>" class="course__title-link">
						<?php the_title(); ?>
					</a>
				</h4>
				<?php endif; ?>
			 </div>
			<div class="course__content--meta"> 

				<?php if (!$learnpress_archive_hide_lessons): 
				        $course = \LP_Global::course();
				        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
				        $lessons_text = ('1' == $lessons) ? esc_html__('Lesson', 'lmsmart') : esc_html__('Lessons', 'lmsmart');
				        printf('<span class="course-lessons"> <i class="flaticon-book-1"></i>  %s %s</span>', $lessons, $lessons_text);
				 endif; ?>
				<?php if (!$learnpress_archive_hide_lessons): ?>
					<span class="course-lessons">
					<i class="flaticon-wall-clock"> </i> <?php echo learn_press_get_post_translated_duration( get_the_ID(), esc_html__( ' Lifetime access', 'lmsmart' ) ); ?>
					</span>
				<?php endif; ?>

			</div>
             <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>

			<div class="btn__wrap">
				<a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'lmsmart' ); ?></a>
			</div>
		</div>
	<?php endif; ?>

	<div class="course__container">

	<div class="tpc-video_popup with_image">
			<div class="videobox_content">

			<?php if (!$learnpress_archive_hide_media): ?>
				<div class="course__media">

					<?php if ( has_post_thumbnail() ):?>
					  <a class="course__media-link" href="<?php the_permalink(); ?>">
					    <?php the_post_thumbnail('medium');?>
					  </a>
					 <?php endif; ?>
				</div>
			<?php endif; ?>

				<?php       
					if (class_exists('RWMB_Loader') && $learnpress_tf_hover_popup_type == 'show_video_popup') {
					$lp_intro_video = rwmb_meta('lp_intro_video');
				?>

				<div class="videobox_link_wrapper">

					<div class="videobox_link" data-lity="" href="<?php echo esc_url(  $lp_intro_video ); ?>">
						<svg class="videobox_icon" width="33%" height="33%" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"></path>
						</svg>
					</div>
				</div>
			<?php  }  // End video popup ?>

		</div>
	</div>

		<div class="course__content">
			<div class="course__content--info">
				<div class="course__top-meta">

					 <?php if (!$learnpress_archive_hide_categories): ?>
						<div class="course__categories ">
							<?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
						</div>
					 <?php endif; ?>
					 <div class="price">
					 	  <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
					 </div>

				</div>
				<?php if (!$learnpress_archive_hide_title): ?>
					<?php         
						ob_start();
						learn_press_courses_loop_item_instructor();
						$author_name = ob_get_clean();
					?>
				<?php endif; ?>

				<?php if (!$learnpress_archive_hide_title): ?>
				<h4 class="course__title">
					<a href="<?php the_permalink(); ?>" class="course__title-link">
						<?php the_title(); ?>
					</a>
				</h4>
				<?php endif; ?>
				<?php if (!$learnpress_archive_hide_instructor): ?>
			        <div class="tpc-course-author-name">
			            <?php echo get_the_author(); ?>
			        </div>
				<?php endif; ?>
			</div>

			<div class="course__content--meta"> 
				<div class="course__meta-left">
					<?php if (!$learnpress_archive_hide_students): ?>
							<?php $students = (int)learn_press_get_course()->count_students(); ?>
							<span class="course-students"><i class="flaticon-user-2"></i> <?php echo esc_html($students); ?> </span>
					<?php endif; ?>

					<?php if (!$learnpress_archive_hide_lessons): ?>
						<?php         
					        $course = \LP_Global::course();
					        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
					        printf('<span class="course-lessons"><i class="flaticon-book-1"></i> %s </span>', $lessons);
						?>
					<?php endif; ?>
				</div>
				<?php if (!$learnpress_archive_hide_reviews && class_exists('LP_Addon_Course_Review_Preload')): ?>
				<div class="course__meta-right">
					<div class="course__review">
				
						<?php
							$course_id       = get_the_ID();
							$course_rate_res = learn_press_get_course_rate( $course_id, false );
							$course_rate     = $course_rate_res['rated'];
							$total           = $course_rate_res['total'];
							learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
						?>
					</div>
				</div>
		         <?php endif; ?>
		       
			</div>
		</div>
	</div>

</article>

<?php elseif ($learnpress_archive_layout == '2'): ?>
<article class="tpc-course">
		<?php if ($learnpress_tf_hover_popup_type == 'show_content_popup'): ?>
		<div class="course__popup-wrap">

			  <div class="courses-content">

				<div class="course__top-meta">
					 <?php if (!$learnpress_archive_hide_categories): ?>
						<div class="course__categories ">
							<?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
						</div>
					 <?php endif; ?>
					 <div class="price">
					 	  <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
					 </div>
				</div>

				<?php if (!$learnpress_archive_hide_title): ?>
				<h4 class="course__title">
					<a href="<?php the_permalink(); ?>" class="course__title-link">
						<?php the_title(); ?>
					</a>
				</h4>
				<?php endif; ?>
				<?php if (!$learnpress_archive_hide_reviews && class_exists('LP_Addon_Course_Review_Preload')): ?>
					<div class="course__review">
				
						<?php
							$course_id       = get_the_ID();
							$course_rate_res = learn_press_get_course_rate( $course_id, false );
							$course_rate     = $course_rate_res['rated'];
							$total           = $course_rate_res['total'];
							learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
						?>
					</div>
		         <?php endif; ?>
			 </div>
			<div class="course__content--meta"> 

				<?php if (!$learnpress_archive_hide_lessons): 
				        $course = \LP_Global::course();
				        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
				        $lessons_text = ('1' == $lessons) ? esc_html__('Lesson', 'lmsmart') : esc_html__('Lessons', 'lmsmart');
				        printf('<span class="course-lessons"> <i class="flaticon-book-1"></i>  %s %s</span>', $lessons, $lessons_text);
				 endif; ?>
				<?php if (!$learnpress_archive_hide_lessons): ?>
					<span class="course-lessons">
					<i class="flaticon-wall-clock"> </i> <?php echo learn_press_get_post_translated_duration( get_the_ID(), esc_html__( ' Lifetime access', 'lmsmart' ) ); ?>
					</span>
				<?php endif; ?>

			</div>
            <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>

			<div class="btn__wrap">
				<a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'lmsmart' ); ?></a>
			</div>
		</div>
		<?php endif ?>
	<div class="course__container">


		<?php if (!$learnpress_archive_hide_media): ?>
			<div class="course__media">

				<?php if ( has_post_thumbnail() ):?>
				  <a class="course__media-link" href="<?php the_permalink(); ?>">
				    <?php the_post_thumbnail('medium');?>
				  </a>
				 <?php endif; ?>
			</div>
		<?php endif ?>


		<div class="course__content">
			<div class="course__content--info">
				<div class="course__top-meta">

					 <?php if (!$learnpress_archive_hide_categories): ?>
						<div class="course__categories ">
							<?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
						</div>
					 <?php endif; ?>
						 <div class="price-round">
							 <?php get_template_part('templates/learnpress/price_within_button'); ?>
						</div>
				</div>
				<?php if (!$learnpress_archive_hide_title): ?>
					<?php         
						ob_start();
						learn_press_courses_loop_item_instructor();
						$author_name = ob_get_clean();
					?>
				<?php endif; ?>

				<?php if (!$learnpress_archive_hide_title): ?>
				<h4 class="course__title">
					<a href="<?php the_permalink(); ?>" class="course__title-link">
						<?php the_title(); ?>
					</a>
				</h4>
				<?php endif; ?>
				<?php if (!$learnpress_archive_hide_instructor): ?>
			        <div class="tpc-course-author-name">
			        	 <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
			            <?php echo get_the_author(); ?>
			        </div>
				<?php endif; ?>
			</div>

			<div class="course__content--meta"> 
				<div class="course__meta-left">
					<?php if (!$learnpress_archive_hide_students): ?>
							<?php $students = (int)learn_press_get_course()->count_students(); ?>
							<span class="course-students"><i class="flaticon-user-2"></i> <?php echo esc_html($students); ?> </span>
					<?php endif; ?>

					<?php if (!$learnpress_archive_hide_lessons): ?>
						<?php         
					        $course = \LP_Global::course();
					        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
					        printf('<span class="course-lessons"><i class="flaticon-book-1"></i> %s </span>', $lessons);
						?>
					<?php endif; ?>
				</div>
				<?php if (!$learnpress_archive_hide_reviews && class_exists('LP_Addon_Course_Review_Preload')): ?>
				<div class="course__meta-right">
					<div class="course__review">
				
						<?php
							$course_id       = get_the_ID();
							$course_rate_res = learn_press_get_course_rate( $course_id, false );
							$course_rate     = $course_rate_res['rated'];
							$total           = $course_rate_res['total'];
							learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
						?>
					</div>
				</div>
		         <?php endif; ?>
		       
			</div>
		</div>
	</div>

</article>
<?php else : ?>	
<article class="tpc-course">

		<?php if ($learnpress_tf_hover_popup_type == 'show_content_popup'): ?>
		<div class="course__popup-wrap">

			  <div class="courses-content">

				<div class="course__top-meta">
					 <?php if (!$learnpress_archive_hide_categories): ?>
						<div class="course__categories ">
							<?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
						</div>
					 <?php endif; ?>
					 <div class="price">
					 	  <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
					 </div>
				</div>

				<?php if (!$learnpress_archive_hide_title): ?>
				<h4 class="course__title">
					<a href="<?php the_permalink(); ?>" class="course__title-link">
						<?php the_title(); ?>
					</a>
				</h4>
				<?php endif; ?>
				<?php if (!$learnpress_archive_hide_reviews && class_exists('LP_Addon_Course_Review_Preload')): ?>
					<div class="course__review">
				
						<?php
							$course_id       = get_the_ID();
							$course_rate_res = learn_press_get_course_rate( $course_id, false );
							$course_rate     = $course_rate_res['rated'];
							$total           = $course_rate_res['total'];
							learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
						?>
					</div>
		         <?php endif; ?>
			 </div>
			<div class="course__content--meta"> 

				<?php if (!$learnpress_archive_hide_lessons): 
				        $course = \LP_Global::course();
				        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
				        $lessons_text = ('1' == $lessons) ? esc_html__('Lesson', 'lmsmart') : esc_html__('Lessons', 'lmsmart');
				        printf('<span class="course-lessons"> <i class="flaticon-book-1"></i>  %s %s</span>', $lessons, $lessons_text);
				 endif; ?>
				<?php if (!$learnpress_archive_hide_lessons): ?>
					<span class="course-lessons">
					<i class="flaticon-wall-clock"> </i> <?php echo learn_press_get_post_translated_duration( get_the_ID(), esc_html__( ' Lifetime access', 'lmsmart' ) ); ?>
					</span>
				<?php endif; ?>

			</div>
             <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>

			<div class="btn__wrap">
				<a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'lmsmart' ); ?></a>
			</div>
		</div>
		<?php endif ?>
	<div class="course__container">


<div class="tpc-video_popup with_image">
		<div class="videobox_content">

		<?php if (!$learnpress_archive_hide_media): ?>
			<div class="course__media">

				<?php if ( has_post_thumbnail() ):?>
				  <a class="course__media-link" href="<?php the_permalink(); ?>">
				    <?php the_post_thumbnail('medium');?>
				  </a>
				 <?php endif; ?>
			</div>
		<?php endif ?>

			<?php       
				if (class_exists('RWMB_Loader') && $learnpress_tf_hover_popup_type == 'show_video_popup') {
				$lp_intro_video = rwmb_meta('lp_intro_video');
			?>

			<div class="videobox_link_wrapper">

				<div class="videobox_link" data-lity="" href="<?php echo esc_url(  $lp_intro_video ); ?>">
					<svg class="videobox_icon" width="33%" height="33%" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"></path>
					</svg>
				</div>
			</div>
		<?php  }  // End video popup ?>

	</div>
</div>

		<div class="course__content">
			<div class="course__content--info">
				<div class="course__top-meta">

					 <?php if (!$learnpress_archive_hide_categories): ?>
						<div class="course__categories ">
							<?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
						</div>
					 <?php endif; ?>
				</div>
				<?php if (!$learnpress_archive_hide_title): ?>
					<?php         
						ob_start();
						learn_press_courses_loop_item_instructor();
						$author_name = ob_get_clean();
					?>
				<?php endif; ?>

				<?php if (!$learnpress_archive_hide_title): ?>
				<h4 class="course__title">
					<a href="<?php the_permalink(); ?>" class="course__title-link">
						<?php the_title(); ?>
					</a>
				</h4>
				<?php endif; ?>
				<?php if (!$learnpress_archive_hide_instructor): ?>
			        <div class="tpc-course-author-name">
			        	 <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
			            <?php echo get_the_author(); ?>
			        </div>
				<?php endif; ?>
			</div>

			<div class="course__content--meta"> 
				<div class="course__meta-left">

				<?php if (!$learnpress_archive_hide_students): ?>
						<?php $students = (int)learn_press_get_course()->count_students(); ?>
						<span class="course-students"><i class="flaticon-user-2"></i> <?php echo esc_html($students); ?> </span>
				<?php endif; ?>

				<?php if (!$learnpress_archive_hide_lessons): ?>
					<?php         
				        $course = \LP_Global::course();
				        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
				        printf('<span class="course-lessons"><i class="flaticon-book-1"></i> %s </span>', $lessons);
					?>
				<?php endif; ?>

				<?php if (!$learnpress_archive_hide_reviews && class_exists('LP_Addon_Course_Review_Preload')) : ?>
				<?php 
					$total_reviews = learn_press_get_course_rate_total(get_the_ID());
			        $reviews_title = !empty($total_reviews) ? sprintf(_n('review is submitted', 'reviews are submitted', $total_reviews, 'lmsmart'), number_format_i18n($total_reviews)) : esc_html__('No any reviews yet', 'lmsmart');
			        printf(
			            '<span class="course-reviews" title="%1$s %2$s"><i class="flaticon-star-1"></i> %1$d </span>',
			            $total_reviews,
			            $reviews_title,
			        );
		         ?>
		         <?php endif; ?>
		     	</div>

		         <?php if (!$lp_archive_hide_enroll_btn): ?>	
					<div class="course__meta-right">
						 <div class="price">
							 <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
						</div>
		             </div>
				 <?php endif ?>
			</div>
		</div>
	</div>

</article>
<?php endif ?>
<?php } //if class exist learnpress ?>