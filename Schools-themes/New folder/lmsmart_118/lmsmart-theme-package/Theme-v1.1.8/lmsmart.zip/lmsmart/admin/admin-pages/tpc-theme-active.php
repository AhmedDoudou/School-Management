


	<h2 class="nav-tab-wrapper">
		<?php

		printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-admin-menu' ), esc_html__( 'Welcome', 'lmsmart' ) );

		printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-theme-active' ), esc_html__( 'Activate Theme', 'lmsmart' ) );

		printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=tpc-theme-options-panel' ), esc_html__( 'Theme Options', 'lmsmart' ) );

		if (class_exists('OCDI_Plugin')):
			printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'themes.php?page=pt-one-click-demo-import' ), esc_html__( 'Demo Import', 'lmsmart' ) );
		endif;

        printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-requirements' ), esc_html__( 'Requirements', 'lmsmart' ) );
		
		printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-help-center' ), esc_html__( 'Help Center', 'lmsmart' ) );

		?>
	</h2>
	
	
	<div class="lmsmart-section nav-tab-active" id="activate-theme">

	<?php lmsmart_tv_options_page(); ?>

	</div>

