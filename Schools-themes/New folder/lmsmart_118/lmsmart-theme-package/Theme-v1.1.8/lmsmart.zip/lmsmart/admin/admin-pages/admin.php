<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $pagenow;

function lmsmart_welcome_page(){
   require_once 'tpc-welcome.php';
}

function lmsmart_theme_active_page(){
   require_once 'tpc-theme-active.php';
}

function lmsmart_help_center_page(){
   require_once 'tpc-help-center.php';
}

function lmsmart_requirements_page(){
   require_once 'tpc-requirements.php';
}

function lmsmart_admin_menu(){
    if ( current_user_can( 'edit_theme_options' ) ) {

        add_menu_page( 'LMSMart', 'LMSMart', 'administrator', 'lmsmart-admin-menu', 'lmsmart_welcome_page', 'data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAUCAYAAABiS3YzAAAEhElEQVQ4jW2UWYwUVRiFv3tr7a7eprtn6BlmVUBGosIkRpQEBZeoL8QEjDGiLz5piC8+qW+GJzXw4BJNjNEXYzQmaDDENYAGoyCgBGSQ2WC27p5eZnqr7qouUwWd4OCf3FRuLafOf/5zj9j2/aesrorTYn0kId/acv++biN8UJNyItuo/e15nh1StZwi5HJYUQ1Nyt+BQ8DyjRDK4LO7bwKVQnYvNqpbjyxMjSpCDCdUwzsyP5X/ePK8daq46J0t5SYW7GqjL2Q9FFa0GHARsDvfq6vw/P12TYi9UtN3X6mtRN65dIaMaXFXV/qWz6+M89XcZTQph+K68f65Um7ihfVbnlgbioSAD4DSaqY68AzwJrADD12XKusiCW6NJEiZJveketEVSbnV7Lfb7q7juVmRbdR/3RhPjaV0M32dcaMDKoCngANAn79pei6GorBn8DYarsvLZ4+SNEz2DGygWw+xLppkxEqMXqoU1YwZProxmtqjCDECnO+0vwl4HUj6G+/6klIghSATtoioGm+Pn6ZkN7gv3UfcMNmc6ObJwQ07Wm3XrDqt/oRu7AVO+ExN4BXgkRvFdT2PaqtJoWmzKZ7k0d4RbNflWG42WN8tTpMJWQxbMc6U8gNDVnTp8Pzk/jsT3Sd90DHgDcDsANrtNpqQxDSD6VqZyWqZgXCMB7oHuCORDmQJSZV70318uzCDqag4bW/ixVM/vJpt1KZ90OeAxzuAdcfBUjUezgyRCEBXyNs1Tpdy5Ow6acPk9liS7T39ZBt1FuwqO3r6OTw/Gc3b9eO/FRYu+5pu7gA2XCfQ7rHeIVJG2G8LRQhieoiq2+KX/CxnS1l6jBBRVUdTFJ4eGkUIwXS1HA2r6nCP0aVIIB0Atl0ims6DmUEUKfny6iWmKmUiihYMLaLopHSTZtvlr/ISP+fnGLHibEv3EdP0QBKJjDiep6gCWnbbJaZqbE2uDezzY/YqBbuOImTA0FK0wHT+oCxVZ41pMVtfYY0ZptxscLqYpdJyfKe4vnFUu+1O+K34Ayg6dc6V8lRcB11RSOsmUU1nsVGl0moF9trZM0DNcfA86DMjvpZ8NnMxuKdKuQg4MqGZx4etOLlGnT9LOey2g69JvxnhoZ4hujSDYtPG8dpsTfYxaEWZrJWDGZwsLHJkfoZys+lrnxMwHTCNasaxnF37I2/Xx1w82p6gN2RxdyrDTG0l0M+vsa4eRiKxQJqpajmw1LHc1eBnIVX11TkC/BMEkiKYW7LrBzoOyJjhQIqLK0ucKMxSc1uMxpKMROKcKmYZXy5gSBWEoOW1g8mLa9H3BZAPQBcaVf/JNxI+SuomQ9F48OGF5SJtDwZDsWBdKBcYrxTRpRLYzM+HzhV4D/jp+ulG9Y8jUNCksj+hGcmJ5dKuQrMe6NplmGTCEabry8xUl9GFDIa1qj4EDgIrN+WpQFx2Pe+lgl2fkIqyz5RS9Zn7p2muXgm8Kzu8rpUP4sfku522/zekPZj24DVViEOmVJ8v282dJcdOqcLPq84rzANfA58AZ4DWf5gD/wJ4MtlVNRLHqgAAAABJRU5ErkJggg==', 2 );

        add_submenu_page( 'lmsmart-admin-menu', 'lmsmart', esc_html__('Welcome','lmsmart'), 'administrator', 'lmsmart-admin-menu', 'lmsmart_welcome_page' );

        add_submenu_page( 'lmsmart-admin-menu', 'lmsmart', esc_html__('Activate Theme','lmsmart'), 'administrator', 'lmsmart-theme-active', 'lmsmart_theme_active_page' );

        add_submenu_page('lmsmart-admin-menu', '', 'Theme Options', 'manage_options', 'admin.php?page=tpc-theme-options-panel' );

        if (class_exists('OCDI_Plugin')):
           add_submenu_page( 'lmsmart-admin-menu', esc_html__( 'Demo Import', 'lmsmart' ), esc_html__( 'Demo Import', 'lmsmart' ), 'administrator', 'demo_install', 'demo_install_function' );
       endif;

      add_submenu_page( 'lmsmart-admin-menu', 'lmsmart', esc_html__('Requirements','lmsmart'), 'administrator', 'lmsmart-requirements', 'lmsmart_requirements_page' );

      add_submenu_page( 'lmsmart-admin-menu', 'lmsmart', esc_html__('Help Center','lmsmart'), 'administrator', 'lmsmart-help-center', 'lmsmart_help_center_page' );

   }

}

add_action( 'admin_menu', 'lmsmart_admin_menu' );

function demo_install_function(){
    ?>
    <script>location.href='<?php echo esc_url(admin_url().'themes.php?page=pt-one-click-demo-import');?>';</script>
    <?php
}

if ( is_admin() && 'themes.php' == $pagenow && isset( $_GET['activated'] ) ) {

  wp_redirect(admin_url("admin.php?page=lmsmart-admin-menu"));
  
}









