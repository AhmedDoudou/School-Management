<?php

add_filter('admin_body_class', 'lmsmart_admin_body_class');

function lmsmart_admin_body_class($classes)
{

    if (lmsmart_check_tvc()) {
        return "$classes no_lmsmart_unlock";
    } else {
        return "$classes lmsmart_unlock";
    }
}

function lmsmart_tvf_register_settings()
{
    add_option('lmsmart_tv_option', '');
    register_setting('lmsmart_tv_options_group', 'lmsmart_tv_option', 'lmsmart_tv_callback');
}
add_action('admin_init', 'lmsmart_tvf_register_settings');

function lmsmart_tvf_register_options_page()
{
    add_options_page('Theme Verify', 'Theme Verify', 'manage_options', 'lmsmart_tvf', 'lmsmart_tv_options_page');
}
add_action('admin_menu', 'lmsmart_tvf_register_options_page');

function lmsmart_tv_options_page()
{
    ?>
<div class="lmsmart-activation-theme_form">
    <div class="container-form">
<form method="post" action="options.php">
      <?php settings_fields('lmsmart_tv_options_group');?>

        <h1 class="lmsmart-title"><?php esc_html_e('Activate Your Licence', 'lmsmart');?></h1>
        <div class="lmsmart-content">
            <p class="lmsmart-content_subtitle">
                <?php echo sprintf(esc_html__('Welcome and thank you for Choosing %s Theme!', 'lmsmart'), esc_html(wp_get_theme()->get('Name'))); ?>
                <br/>
                <?php echo sprintf(esc_html__('The %s theme needs to be activated to enable demo import installation and customer support service.', 'lmsmart'), esc_html(wp_get_theme()->get('Name'))); ?>
            </p>
        </div>

        <?php if (lmsmart_check_tvc() == false): ?>
        <div class="help-description">
            <a href="https://www.youtube.com/watch?v=yTScONNFnZ8&feature=emb_title&ab_channel=Envato" target="_blank"><?php esc_html_e('How to find purchase code?', 'lmsmart');?></a>
        </div>

        <input type="text" placeholder="Enter Your Purchase Code"  id="lmsmart_tv_option" name="lmsmart_tv_option" value="<?php echo get_option('lmsmart_tv_option'); ?>" />

           <div class="licnese-active-button">
                <?php submit_button(__('Activate', 'lmsmart'), 'primary');?>
           </div>
        <?php endif;?>

        <div class="form-group hidden_group">
            <input type="hidden" name="deactivate_theme" value=" " class="form-control">
        </div>

        <?php
            $theme_fv_code = get_option('lmsmart_tv_option');
            if (!empty($theme_fv_code)) {
                ?>
                        <input type="hidden" name="lmsmart_tv_option" value=" " class="form-control">
                    <?php
            }
        ?>

        <?php wp_nonce_field('purchase-activation', 'security');?>

        <?php if (lmsmart_check_tvc()): ?>
            <button type="submit" class="button button-primary deactivate_theme-license" value="submit">
                <span class="text-btn"><?php esc_html_e('Deactivate', 'lmsmart');?></span>
                <span class="loading-icon"></span>
            </button>
        <?php endif;?>

      </form>


        <?php
            if (lmsmart_check_tvc()) {
        ?>

        <div class="lmsmart-activation-theme_congratulations">
            <h1 class="lmsmart-title">
                <?php esc_html_e('Thank you!', 'lmsmart');?>
            </h1>
            <span><?php esc_html_e('Your theme\'s license is activated successfully.', 'lmsmart');?></span>

        </div>
            <a href="<?php echo admin_url('themes.php?page=pt-one-click-demo-import'); ?>" class="button button-primary button-large button-next import-demo-next"><?php esc_html_e('Import Demo', 'lmsmart');?></a>
        <?php

    } else {

        $theme_fv_code = get_option('lmsmart_tv_option');?>

        <?php if (!empty($theme_fv_code)): ?>
             <div class="lmsmart-activation-theme_congratulations invalid">
                <h1 class="lmsmart-title">
                   <?php esc_html_e('Invalid Purchase Code', 'lmsmart');?>
                </h1>
            </div>
        <?php endif?>

        <?php }?>

    </div>
</div>
 <?php
}

class LMSMartEnvatoApi
{
    // Bearer, no need for OAUTH token, change this to your bearer string
    // https://build.envato.com/api/#token

    private static $bearer = "uYJt07Y0Wz9Eum0mX3hsUJtTotYhU"."v"."e"."y"; //

    public static function getPurchaseData($code)
    {

        //setting the header for the rest of the api
        $bearer   = 'bearer ' . self::$bearer;
        $header   = array();
        $header[] = 'Content-length: 0';
        $header[] = 'Content-type: application/json; charset=utf-8';
        $header[] = 'Authorization: ' .$bearer;

        $verify_url = 'https://api.envato.com/v3/market/author/sale/';
        $ch_verify  = curl_init($verify_url . '?code=' . $code);

        curl_setopt($ch_verify, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch_verify, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch_verify, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch_verify, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch_verify, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');

        $cinit_verify_data = curl_exec($ch_verify);
        curl_close($ch_verify);

        if ($cinit_verify_data != "") {
            return json_decode($cinit_verify_data);
        } else {
            return false;
        }

    }

    public static function verifyPurchase($code)
    {
        $verify_obj = self::getPurchaseData($code);

        // Check for correct verify code
        if (
            (false === $verify_obj) ||
            !is_object($verify_obj) ||
            isset($verify_obj->error) ||
            !isset($verify_obj->sold_at)
        ) {
            return -1;
        }

        // If empty or date present, then it's valid
        if (
            $verify_obj->supported_until == "" ||
            $verify_obj->supported_until != null
        ) {
            return $verify_obj;
        }

        // Null or something non-string value, thus support period over
        return 0;

    }
}

function lmsmart_check_tvc()
{
    $theme_fv_code = get_option('lmsmart_tv_option');

    if (isset($theme_fv_code)) {
        $purchase_code = htmlspecialchars($theme_fv_code);

        $obj = LMSMartEnvatoApi::verifyPurchase($theme_fv_code);

        if (is_object($obj)) {
            return true;
        }
    }
}

// function lmsmart_check_tvc()
// {

//     $theme_fv_code = trim(get_option('lmsmart_tv_option'));

//     if (!empty($theme_fv_code && strlen($theme_fv_code) == '36')) {
//         return true;
//     }
  
// }

function lmsmart_import_files()
{
    return array(

        array(
            'import_file_name'             => 'Home V1 (LearnPress)',
            'categories'                   => array('LearnPress'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/lp/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/lp/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/lp/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'screenshot.png',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/lp/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),

        array(
            'import_file_name'             => 'Home V1 (Tutor)',
            'categories'                   => array('Tutor'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/tutor/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/tutor/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/tutor/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'screenshot.png',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/tutor/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/tutor/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),

        array(
            'import_file_name'             => 'Home V1 (LearnDash)',
            'categories'                   => array('LearnDash'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/ld/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/ld/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/ld/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'screenshot.png',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/ld/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),

        array(
            'import_file_name'             => 'Home V2 (LearnPress)',
            'categories'                   => array('LearnPress'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/lp/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/lp/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/lp/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_2.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/lp/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v2-learnpress/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),

        array(
            'import_file_name'             => 'Home V2 (Tutor)',
            'categories'                   => array('Tutor'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/tutor/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/tutor/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/tutor/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_2.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/tutor/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/tutor/home-v2-tutor/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),

        array(
            'import_file_name'             => 'Home V2 (LearnDash)',
            'categories'                   => array('LearnDash'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/ld/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/ld/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/ld/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_2.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/ld/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/home-v2-learndash/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),

        array(
            'import_file_name'             => 'Home V3 (LearnPress)',
            'categories'                   => array('LearnPress'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/lp/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/lp/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/lp/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_3.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/lp/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v3-learnpress/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
        
        array(
            'import_file_name'             => 'Home V3 (Tutor)',
            'categories'                   => array('Tutor'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/tutor/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/tutor/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/tutor/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_3.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/tutor/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/tutor/home-v3-tutor/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
               
        array(
            'import_file_name'             => 'Home V3 (LearnDash)',
            'categories'                   => array('LearnDash'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/ld/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/ld/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/ld/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_3.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/ld/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/home-v3-learndash/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
        
        array(
            'import_file_name'             => 'Home V4 (LearnPress)',
            'categories'                   => array('LearnPress'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/lp/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/lp/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/lp/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_4.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/lp/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v4-learnpress/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
                 
        array(
            'import_file_name'             => 'Home V4 (Tutor)',
            'categories'                   => array('Tutor'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/tutor/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/tutor/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/tutor/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_4.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/tutor/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/tutor/home-v4-tutor/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
                
        array(
            'import_file_name'             => 'Home V4 (LearnDash)',
            'categories'                   => array('LearnDash'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/ld/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/ld/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/ld/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_4.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/ld/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/home-v4-learndash/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
       
        array(
            'import_file_name'             => 'Home V5 (LearnPress)',
            'categories'                   => array('LearnPress', 'Cooking/Recipe'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/lp/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/lp/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/lp/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_5.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/lp/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v5-learnpress/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
                 
        array(
            'import_file_name'             => 'Home V5 (Tutor)',
            'categories'                   => array('Tutor', 'Cooking/Recipe'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/tutor/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/tutor/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/tutor/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_5.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/tutor/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/tutor/home-v5-tutor/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
                
        array(
            'import_file_name'             => 'Home V5 (LearnDash)',
            'categories'                   => array('LearnDash', 'Cooking/Recipe'),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'admin/demo/ld/content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'admin/demo/ld/widget_data.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'admin/demo/ld/customizer.dat',
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_5.jpg',
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'admin/demo/ld/redux.json',
                    'option_name' => 'lmsmart_set',
                ),
            ),
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/home-v5-learndash/',
            'import_notice'                => __("-  Don't activate more than one LMS plugin at the same site. Otherwise, same LMS page URL will create a problem. <br> <br>- Images do not include in demo import If you want to use images from demo content, you should check the license for every image.", 'lmsmart'),
        ),
       


    );
}

function lmsmart_import_flies()
{
    return array(

          array(
            'import_file_name'             => 'Home V1 (LearnPress)',
            'categories'                   => array('LearnPress'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'screenshot.png',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/',
        ),
          array(
            'import_file_name'             => 'Home V1 (Tutor)',
            'categories'                   => array('Tutor'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'screenshot.png',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/tutor/',
        ),
          array(
            'import_file_name'             => 'Home V1 (LearnDash)',
            'categories'                   => array('LearnDash'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'screenshot.png',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/',
        ),
        array(
            'import_file_name'             => 'Home V2 (LearnPress)',
            'categories'                   => array('LearnPress'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_2.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v2/',
        ),
        array(
            'import_file_name'             => 'Home V2 (Tutor)',
            'categories'                   => array('Tutor'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_2.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v2-tutor/',
        ),
        array(
            'import_file_name'             => 'Home V2 (LearnDash)',
            'categories'                   => array('LearnDash'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_2.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/home-v2-learndash/',
        ),
        array(
            'import_file_name'             => 'Home V3 (LearnPress)',
            'categories'                   => array('LearnPress'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_3.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v3-learnpress/',
        ),
        array(
            'import_file_name'             => 'Home V3 (Tutor)',
            'categories'                   => array('Tutor'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_3.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v3-tutor/',
        ),
        
        array(
            'import_file_name'             => 'Home V3 (LearnDash)',
            'categories'                   => array('LearnDash'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_3.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/home-v3-learndash/',
        ),
        
        array(
            'import_file_name'             => 'Home V4 (LearnPress)',
            'categories'                   => array('LearnPress'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_4.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v4-learnpress/',
        ),
          
        array(
            'import_file_name'             => 'Home V4 (Tutor)',
            'categories'                   => array('Tutor'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_4.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v4-tutor/',
        ),
  
        array(
            'import_file_name'             => 'Home V4 (LearnDash)',
            'categories'                   => array('LearnDash'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_4.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/home-v4-learndash/',
        ),
        
        array(
            'import_file_name'             => 'Home V5 (LearnPress)',
            'categories'                   => array('LearnPress','Cooking/Recipe'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_5.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v5-learnpress/',
        ),
          
        array(
            'import_file_name'             => 'Home V5 (Tutor)',
            'categories'                   => array('Tutor','Cooking/Recipe'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_5.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/lp/home-v5-tutor/',
        ),
  
        array(
            'import_file_name'             => 'Home V5 (LearnDash)',
            'categories'                   => array('LearnDash','Cooking/Recipe'),
            'import_preview_image_url'     => trailingslashit(get_template_directory_uri()) . 'admin/demo/screenshots/home_5.jpg',
            'preview_url'                  => 'https://thepixelcurve.com/wp/lmsmart/ld/home-v5-learndash/',
        ),
        
        
    );
}

if (lmsmart_check_tvc()) {
    $lmsmart_tvfi = "lmsmart_import_files";
} else {
    $lmsmart_tvfi = "lmsmart_import_flies";
}
add_filter('pt-ocdi/import_files', $lmsmart_tvfi);

function lmsmart_dialog_options($options)
{
    return array_merge($options, array(
        'width'       => 300,
        'dialogClass' => 'wp-dialog',
        'resizable'   => false,
        'height'      => 'auto',
        'modal'       => true,
    ));
}
add_filter('pt-ocdi/confirmation_dialog_options', 'lmsmart_dialog_options', 10, 1);
add_filter('pt-ocdi/disable_pt_branding', '__return_true');

function lmsmart_after_import_setup($selected_import)
{
    // Assign menus to their locations.
    $main_menu = get_term_by('name', 'Main', 'nav_menu');

    set_theme_mod('nav_menu_locations', array(
        'main_menu' => $main_menu->term_id,
    )
    );

    // LearnPress LMS
    if ('Home V1 (LearnPress)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v1-learnpress');
    } elseif ('Home V2 (LearnPress)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v2-learnpress');
    } elseif ('Home V3 (LearnPress)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v3-learnpress');
    } elseif ('Home V4 (LearnPress)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v4-learnpress');
    } elseif ('Home V5 (LearnPress)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v5-learnpress');
    }
    // Tutor LMS
    elseif ('Home V1 (Tutor)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v1-tutor');
    } elseif ('Home V2 (Tutor)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v2-tutor');
    } elseif ('Home V3 (Tutor)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v3-tutor');
    } elseif ('Home V4 (Tutor)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v4-tutor');
    } elseif ('Home V5 (Tutor)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v5-tutor');
    }
    // LearnDash LMS
    elseif ('Home V1 (LearnDash)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v1-learndash');
    } elseif ('Home V2 (LearnDash)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v2-learndash');
    } elseif ('Home V3 (LearnDash)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v3-learndash');
    } elseif ('Home V4 (LearnDash)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v4-learndash');
    } elseif ('Home V5 (LearnDash)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-v5-learndash');
    }

    //$blog_page_id = get_page_by_title('Blog');
    update_option('show_on_front', 'page');
    update_option('page_on_front', $front_page_id->ID);
    //update_option('page_for_posts', $blog_page_id->ID);

    // Reset site permalink
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure('/%postname%/');

}
add_action('pt-ocdi/after_import', 'lmsmart_after_import_setup');

function ocdi_before_content_import($selected_import)
{
    // Customizer reset
    delete_option('theme_mods_' . get_option('stylesheet'));
    // Old style.
    $theme_name = get_option('current_theme');
    if (false === $theme_name) {
        $theme_name = wp_get_theme()->get('lmsmart');
    }
    delete_option('mods_' . $theme_name);

    // Activate/Deactivate plugins
    // Check LearnPress LMS
    if ('Home V1 (LearnPress)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress/learnpress.php';
        if (file_exists($plugin_file) && !class_exists('LearnPress')) {
            activate_plugin('/learnpress/learnpress.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress-course-review/learnpress-course-review.php';
        if (file_exists($plugin_file) && !class_exists('LP_Addon_Course_Review_Preload')) {
            activate_plugin('/learnpress-course-review/learnpress-course-review.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    elseif ('Home V2 (LearnPress)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress/learnpress.php';
        if (file_exists($plugin_file) && !class_exists('LearnPress')) {
            activate_plugin('/learnpress/learnpress.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress-course-review/learnpress-course-review.php';
        if (file_exists($plugin_file) && !class_exists('LP_Addon_Course_Review_Preload')) {
            activate_plugin('/learnpress-course-review/learnpress-course-review.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    
    elseif ('Home V3 (LearnPress)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress/learnpress.php';
        if (file_exists($plugin_file) && !class_exists('LearnPress')) {
            activate_plugin('/learnpress/learnpress.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress-course-review/learnpress-course-review.php';
        if (file_exists($plugin_file) && !class_exists('LP_Addon_Course_Review_Preload')) {
            activate_plugin('/learnpress-course-review/learnpress-course-review.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    
    elseif ('Home V4 (LearnPress)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress/learnpress.php';
        if (file_exists($plugin_file) && !class_exists('LearnPress')) {
            activate_plugin('/learnpress/learnpress.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress-course-review/learnpress-course-review.php';
        if (file_exists($plugin_file) && !class_exists('LP_Addon_Course_Review_Preload')) {
            activate_plugin('/learnpress-course-review/learnpress-course-review.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    }    
    
    elseif ('Home V5 (LearnPress)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress/learnpress.php';
        if (file_exists($plugin_file) && !class_exists('LearnPress')) {
            activate_plugin('/learnpress/learnpress.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/learnpress-course-review/learnpress-course-review.php';
        if (file_exists($plugin_file) && !class_exists('LP_Addon_Course_Review_Preload')) {
            activate_plugin('/learnpress-course-review/learnpress-course-review.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    }    
    
    // Check Tutor LMS
    if ('Home V1 (Tutor)' === $selected_import['import_file_name']) {
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor/tutor.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor/tutor.php')) {
            activate_plugin('/tutor/tutor.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor-pro/tutor-pro.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor-pro/tutor-pro.php')) {
            activate_plugin('/tutor-pro/tutor-pro.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    elseif ('Home V2 (Tutor)' === $selected_import['import_file_name']) {
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor/tutor.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor/tutor.php')) {
            activate_plugin('/tutor/tutor.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor-pro/tutor-pro.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor-pro/tutor-pro.php')) {
            activate_plugin('/tutor-pro/tutor-pro.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    
    elseif ('Home V3 (Tutor)' === $selected_import['import_file_name']) {
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor/tutor.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor/tutor.php')) {
            activate_plugin('/tutor/tutor.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor-pro/tutor-pro.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor-pro/tutor-pro.php')) {
            activate_plugin('/tutor-pro/tutor-pro.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    
    elseif ('Home V4 (Tutor)' === $selected_import['import_file_name']) {
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor/tutor.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor/tutor.php')) {
            activate_plugin('/tutor/tutor.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor-pro/tutor-pro.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor-pro/tutor-pro.php')) {
            activate_plugin('/tutor-pro/tutor-pro.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    }    
        
    elseif ('Home V5 (Tutor)' === $selected_import['import_file_name']) {
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        if (class_exists('SFWD_LMS')) {
            deactivate_plugins('/sfwd-lms/sfwd_lms.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor/tutor.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor/tutor.php')) {
            activate_plugin('/tutor/tutor.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/tutor-pro/tutor-pro.php';
        if (file_exists($plugin_file) && !is_plugin_active('tutor-pro/tutor-pro.php')) {
            activate_plugin('/tutor-pro/tutor-pro.php');
        }
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    }    
    
    
    // Check LearnDash LMS
    if ('Home V1 (LearnDash)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/sfwd-lms/sfwd_lms.php';
        if (file_exists($plugin_file) && !is_plugin_active('sfwd-lms/sfwd_lms.php')) {
            activate_plugin('/sfwd-lms/sfwd_lms.php');
        }

        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    elseif ('Home V2 (LearnDash)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/sfwd-lms/sfwd_lms.php';
        if (file_exists($plugin_file) && !is_plugin_active('sfwd-lms/sfwd_lms.php')) {
            activate_plugin('/sfwd-lms/sfwd_lms.php');
        }

        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    
    elseif ('Home V3 (LearnDash)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/sfwd-lms/sfwd_lms.php';
        if (file_exists($plugin_file) && !is_plugin_active('sfwd-lms/sfwd_lms.php')) {
            activate_plugin('/sfwd-lms/sfwd_lms.php');
        }

        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    } 
    
    elseif ('Home V4 (LearnDash)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/sfwd-lms/sfwd_lms.php';
        if (file_exists($plugin_file) && !is_plugin_active('sfwd-lms/sfwd_lms.php')) {
            activate_plugin('/sfwd-lms/sfwd_lms.php');
        }

        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    }    
    
    elseif ('Home V5 (LearnDash)' === $selected_import['import_file_name']) {
        if (function_exists('tutor')) {
            deactivate_plugins('/tutor/tutor.php');
        }
        if (function_exists('tutor_pro')) {
            deactivate_plugins('/tutor-pro/tutor-pro.php');
        }
        if (class_exists('LearnPress')) {
            deactivate_plugins('/learnpress/learnpress.php');
        }
        if (class_exists('LP_Addon_Course_Review_Preload')) {
            deactivate_plugins('/learnpress-course-review/learnpress-course-review.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/sfwd-lms/sfwd_lms.php';
        if (file_exists($plugin_file) && !is_plugin_active('sfwd-lms/sfwd_lms.php')) {
            activate_plugin('/sfwd-lms/sfwd_lms.php');
        }

        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    }    
    

}
add_action('pt-ocdi/before_content_import', 'ocdi_before_content_import');

