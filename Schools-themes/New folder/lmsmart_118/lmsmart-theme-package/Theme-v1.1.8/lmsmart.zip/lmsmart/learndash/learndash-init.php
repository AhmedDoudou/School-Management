<?php

/**
 * Custom Course features
 */

function lmsmart_learndash_course_meta()
{

    $ld_archive_hide_media   = LMSMart_Theme_Helper::get_mb_option('ld_archive_hide_media');
    $ld_single_hide_instructor = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_instructor');
    $ld_single_hide_price = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_instructor');
    $ld_single_hide_topic      = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_topic');
    $ld_single_hide_quiz       = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_quiz');
    $ld_single_hide_enrolled   = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_enrolled');
    $ld_single_hide_duration   = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_duration');
    $tf_duration_h_text   = LMSMart_Theme_Helper::get_mb_option('tf_duration_h_text');
    $tf_duration_m_text   = LMSMart_Theme_Helper::get_mb_option('tf_duration_m_text');
    $ld_single_hide_lesson     = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_lesson');
    $ld_single_hide_category   = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_category');
    $ld_single_hide_language   = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_language');

    $ld_free_text      = LMSMart_Theme_Helper::get_mb_option('ld_free_text');
    $ld_enrolled_text  = LMSMart_Theme_Helper::get_mb_option('ld_enrolled_text');
    $ld_completed_text = LMSMart_Theme_Helper::get_mb_option('ld_completed_text');

    $ld_tf_popup_video_single = LMSMart_Theme_Helper::get_mb_option('ld_tf_popup_video_single');

    $ld_intro_video_source = LMSMart_Theme_Helper::get_mb_option('ld_intro_video_source');

    $ld_single_hide_social = LMSMart_Theme_Helper::get_mb_option('ld_single_hide_social');


    global $post;
    $post_id    = $post->ID;
    $course_id  = $post_id;
    $user_id    = get_current_user_id();
    $current_id = $post->ID;


    $cg_short_description = get_post_meta( $post->ID, '_learndash_course_grid_short_description', true );
    $enable_video = get_post_meta( $post->ID, '_learndash_course_grid_enable_video_preview', true );
    $embed_code   = get_post_meta( $post->ID, '_learndash_course_grid_video_embed_code', true );

    $duration      = get_post_meta( $post_id, '_learndash_course_grid_duration', true );
    $duration_h = is_numeric( $duration ) ? floor( $duration / HOUR_IN_SECONDS ) : null;
    $duration_m = is_numeric( $duration ) ? floor( ( $duration % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS ) : null;

    $options = get_option('sfwd_cpt_options');

    $currency = null;

    if (!is_null($options)) {
        if (isset($options['modules']) && isset($options['modules']['sfwd-courses_options']) && isset($options['modules']['sfwd-courses_options']['sfwd-courses_paypal_currency'])) {
            $currency = $options['modules']['sfwd-courses_options']['sfwd-courses_paypal_currency'];
        }

    }

    if (is_null($currency)) {
        $currency = 'USD';
    }

    $course_options = get_post_meta($post_id, "_sfwd-courses", true);

    $price = $course_options && isset($course_options['sfwd-courses_course_price']) ? $course_options['sfwd-courses_course_price'] : $ld_free_text;

    $has_access   = sfwd_lms_has_access($course_id, $user_id);
    $is_completed = learndash_course_completed($user_id, $course_id);

    if ($price == '') {
        $price .= $ld_free_text;
    }

    if (is_numeric($price)) {
        if ($currency == "USD") {
            $price = '$' . $price;
        } else {
            $price .= ' ' . $currency;
        }

    }

    $class       = '';
    $ribbon_text = '';

    if ($has_access && !$is_completed) {
        $class       = 'ld_course_grid_price ribbon-enrolled';
        $ribbon_text = $ld_enrolled_text;
    } elseif ($has_access && $is_completed) {
        $class       = 'ld_course_grid_price';
        $ribbon_text = $learndash_completed_text;
    } else {
        $class       = !empty($course_options['sfwd-courses_course_price']) ? 'ld_course_grid_price price_' . $currency : 'ld_course_grid_price free';
        $ribbon_text = $price;
    }

    ?>
    <div class="learndash-single-course-meta learndash-meta-top">

        <div class="tpc-video_popup with_image">
                <div class="videobox_content">

                <?php if (!$ld_archive_hide_media): ?>
                    <div class="course__media">

                        <?php if ( has_post_thumbnail() ):?>
                         
                            <?php the_post_thumbnail('large');?>

                         <?php endif; ?>
                    </div>
                <?php endif; ?>

                    <?php       
                        if (class_exists('RWMB_Loader') && $ld_tf_popup_video_single && $ld_intro_video_source == 'ld_intro_video_by_theme_option') {
                            $ld_intro_video = rwmb_meta('ld_intro_video');
                        }
                        else {
                            $ld_intro_video =  $embed_code;
                        }
                    ?>

                    <?php if (class_exists('RWMB_Loader') && !empty($ld_intro_video) && $ld_tf_popup_video_single == '1') { ?>
                    <div class="videobox_link_wrapper">

                        <div class="videobox_link" data-lity="" href="<?php echo esc_url(  $ld_intro_video ); ?>">
                            <svg class="videobox_icon" width="33%" height="33%" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"></path>
                            </svg>
                        </div>
                    </div>
                <?php  }  // End video popup ?>

            </div>
        </div>

        <?php if (!$ld_single_hide_price) {?>
        <div class="course-price">
            <span class="price">
                <?php get_template_part('templates/learndash/price_within_button_2'); ?>   
            </span>
        </div>
        <?php }?>

        <?php if (!$ld_single_hide_instructor) {?>
           <div class="learndash-course-features instructor">
                <span class="meta-label">
                    <i class="meta-icon flaticon-user-1"></i>
                    <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"><?php esc_html_e('Created by', 'lmsmart');?></a>
                </span>

              <div class="meta-value">
                <?php echo get_the_author(); ?>
            </div>
           </div>
        <?php }?>

        <?php if (!$ld_single_hide_duration) {

        ?>
           <div class="learndash-course-features lesson-count">
                <span class="meta-label">
                    <i class="meta-icon flaticon-wall-clock"></i>
                    <?php esc_html_e('Duration', 'lmsmart');?>
                </span>
              <div class="meta-value">
                    <?php if ($duration_h): ?>
                        <?php echo esc_attr($duration_h); ?><?php echo esc_html($tf_duration_h_text); ?>   
                    <?php endif ?>

                    <?php if ($duration_m): ?>
                        <?php echo esc_attr($duration_m); ?><?php echo esc_html($tf_duration_m_text); ?>   
                    <?php endif ?>
              </div>
           </div>
        <?php }?>

        <?php if (!$ld_single_hide_enrolled) {

        $lesson      = learndash_get_course_steps(get_the_ID(), array('sfwd-lessons'));
        $lesson      = $lesson ? count($lesson) : 0;
        $lesson_text = ('1' == $lesson) ? esc_html__('Lesson', 'lmsmart') : esc_html__('Lessons', 'lmsmart');

        ?>
           <div class="learndash-course-features lesson-count">
                <span class="meta-label">
                    <i class="meta-icon flaticon-book-1"></i>
                    <?php esc_html_e('Lessons', 'lmsmart');?>
                </span>
              <div class="meta-value">
                    <?php echo esc_attr($lesson); ?>
                    <?php echo esc_html($lesson_text); ?>
              </div>
           </div>
        <?php }?>

        <?php if (!$ld_single_hide_topic) {

        $topic      = learndash_get_course_steps(get_the_ID(), array('sfwd-topic'));
        $topic      = $topic ? count($topic) : 0;
        $topic_text = ('1' == $topic) ? esc_html__('Topic', 'lmsmart') : esc_html__('Topics', 'lmsmart');
        ?>
           <div class="learndash-course-features topic">
              <span class="meta-label">
               <i class="meta-icon flaticon-edit-file"></i>
                    <?php esc_html_e('Topic', 'lmsmart');?>
            </span>
              <div class="meta-value">
                <?php echo esc_attr($topic); ?>
                <?php echo esc_html($topic_text); ?>
            </div>
           </div>
        <?php }?>

        <?php if (!$ld_single_hide_quiz ) {
        $quiz      = learndash_get_course_steps(get_the_ID(), array('sfwd-quiz'));
        $quiz      = $quiz ? count($quiz) : 0;
        $quiz_text = ('1' == $quiz) ? esc_html__('Quiz', 'lmsmart') : esc_html__('Quizzes', 'lmsmart');
        ?>
           <div class="learndash-course-features duration">
            <span class="meta-label">
                <i class="meta-icon flaticon-question"></i>
                <?php esc_html_e('Quiz', 'lmsmart');?>
            </span>
              <?php echo esc_attr($quiz); ?>
              <?php echo esc_html($quiz_text); ?>
           </div>
        <?php }?>


    <?php if (!$ld_single_hide_category): ?>

       <div class="learndash-course-features categories">

            <span class="meta-label">
                <i class="meta-icon flaticon-price-tag"></i>
                <?php esc_html_e('Category', 'lmsmart');?>
            </span>

          <div class="meta-value">
            <?php
            if (!get_the_terms(get_the_ID(), 'ld_course_category')) {
                    esc_html_e('Uncategorized', 'lmsmart');
                } else {
                    echo get_the_term_list(get_the_ID(), 'ld_course_category', '');
                }
            ?>
          </div>
       </div>
    <?php endif?>


    <?php if (!$ld_single_hide_language): ?>

       <div class="learndash-course-features language">

            <span class="meta-label">
                <i class="meta-icon flaticon-translate"></i>
                <?php esc_html_e('Language', 'lmsmart');?>
            </span>

          <div class="meta-value">
            <?php
            if (!get_the_terms(get_the_ID(), 'ld_course_language')) {
                    esc_html_e('Uncategorized', 'lmsmart');
                } else {
                    echo get_the_term_list(get_the_ID(), 'ld_course_language', '');
                }
            ?>
          </div>
       </div>
    <?php endif?>

    <?php if (class_exists('LMSMart_Theme_Helper') && !$ld_single_hide_social): ?> 
    <div class="lmsmart-course share_post-container">
        <i class="flaticon flaticon-share"></i>  <span> <?php tpc_theme_helper()->render_post_share(); ?><?php esc_html_e( ' Share This Course', 'lmsmart' ); ?></span> 
    </div>
    <?php endif ?>

    </div>

    <?php
}

/**
 * Show course for user archive page
 */

$lmsmart_author_archive_posts_type = LMSMart_Theme_Helper::get_mb_option('lmsmart_author_archive_posts_type');
$lmsmart_author_archive_posts      = LMSMart_Theme_Helper::get_mb_option('lmsmart_author_archive_posts');

if ($lmsmart_author_archive_posts) {
    add_action('pre_get_posts', $lmsmart_author_archive_posts_type);
}

function lmsmart_author_learndash($query)
{
    if (!is_admin() && $query->is_author() && $query->is_main_query()) {
        $query->set('post_type', 'sfwd-courses');
    }
}

function lmsmart_author_any($query)
{
    if (!is_admin() && $query->is_author() && $query->is_main_query()) {
        $query->set('post_type', 'any');
    }
}
