<?php
defined( 'ABSPATH' ) || exit;
use LMSMart_Theme_Helper as LMSMart;
if ( ! class_exists( 'LMSMart_Author_archive' ) ) {
class LMSMart_Author_archive {
     public function __construct() {
          add_action( 'pre_get_posts', [ $this, 'lmsmart_add_cpt_author' ] );
     }
    public function lmsmart_add_cpt_author( $query ) {



        $lmsmart_author_archive_posts_type = LMSMart_Theme_Helper::get_mb_option('lmsmart_author_archive_posts_type');

    

            if ( !is_admin() && $query->is_author() && $query->is_main_query() ) {
                $query->set( 'post_type', 'sfwd-courses'  );
            }
    


     }
}
$var = new LMSMart_Author_archive();
}

