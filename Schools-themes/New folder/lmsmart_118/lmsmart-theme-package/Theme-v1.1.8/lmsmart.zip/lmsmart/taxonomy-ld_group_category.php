<?php

defined('ABSPATH') || exit;

use LMSMart_Theme_Helper as LMSMart;

/**
 * @package lmsmart
 * @author Pixelcurve <help.pixelcurve@gmail.com>
 * @since 1.0.0
 */

$ld_archive_layout = LMSMart_Theme_Helper::get_mb_option('ld_archive_layout');

// Render
get_header();

echo '<div class="learndash-content-area">';
echo '<div class="tpc-courses layout-'.$ld_archive_layout.'">';

        while ( have_posts() ) :
            the_post();

       // LearnDash Archive Template
        get_template_part( 'templates/learndash/learndash_course_group', 'item' ); 

        endwhile;

        echo LMSMart::pagination();

echo '</div>';
echo '</div>';

get_footer();
