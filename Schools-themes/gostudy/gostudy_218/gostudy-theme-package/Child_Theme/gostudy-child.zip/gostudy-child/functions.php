<?php

/**
 * Enqueue parent and child styles
 */
function gostudy_child_enqueue_styles() {
	wp_enqueue_style( 'gostudy-parent', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'gostudy-child', get_stylesheet_directory_uri() . '/style.css', array( 'gostudy-parent' ) );
}

add_action( 'wp_enqueue_scripts', 'gostudy_child_enqueue_styles', 11 );


