<?php

/**
 * Load admin js files
 *
 * @since  1.0
 */

add_action( 'admin_enqueue_scripts', 'gridlove_buddy_load_admin_js' );

function gridlove_buddy_load_admin_js() {

	global $pagenow;	

	if( $pagenow == 'widgets.php' ){
		wp_enqueue_script( 'gridlove-widgets', GRIDLOVE_BUDDY_URL . 'assets/js/admin/widgets.js', array( 'jquery', 'jquery-ui-sortable'), GRIDLOVE_BUDDY_VER );
	}

}

?>