
<?php if ( gridlove_is_woocommerce_active() ) : ?>

	<?php $cart_elements = gridlove_woocommerce_cart_elements(); ?>
	<li class="gridlove-actions-button gridlove-actions-cart">
		<a href="<?php echo esc_url( $cart_elements['cart_url'] ); ?>" class="gridlove-cart"><i class="fa fa-shopping-cart"></i>
		<?php if ( $cart_elements['products_count'] > 0 ) : ?>
			<span class="gridlove-cart-count"><?php echo absint( $cart_elements['products_count'] ); ?></span>
		<?php endif; ?>
		</a>
	</li>
<?php endif; ?>