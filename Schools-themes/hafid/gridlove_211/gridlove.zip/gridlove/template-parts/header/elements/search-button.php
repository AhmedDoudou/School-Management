<li class="gridlove-actions-button gridlove-action-search">
	<span>
		<i class="fa fa-search"></i>
	</span>
	<ul class="sub-menu">
		<li>
			<?php get_search_form(); ?>
		</li>
	</ul>
</li>