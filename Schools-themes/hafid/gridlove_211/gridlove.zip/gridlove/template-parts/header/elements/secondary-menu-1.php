<?php if ( has_nav_menu( 'gridlove_secondary_menu_1' ) ) : ?>
<nav class="secondary-navigation">	
		<?php wp_nav_menu( array( 'theme_location' => 'gridlove_secondary_menu_1', 'container'=> '' ) ); ?>
</nav>
<?php endif; ?>