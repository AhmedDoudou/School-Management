<?php if( gridlove_get_option('single_share_content') && function_exists('meks_ess_share') ): ?>
	<div class="gridlove-content-share">
		<?php meks_ess_share(); ?>
	</div>
<?php endif; ?>