<?php
/**
 * Template Name: Blank Page (full width)
 */
?>

<?php $page_options = gridlove_blank_page_options(); ?>

<?php get_header(); ?>

<?php if ( $page_options['header'] ) : ?>
    <?php get_template_part('template-parts/ads/below-header'); ?>
<?php endif; ?>

<div id="content" class="gridlove-site-content container">

    	<div class="gridlove-content gridlove-full-width">

            <?php while( have_posts() ) : the_post(); ?>
                
               <article id="post-<?php the_ID(); ?>" <?php post_class('gridlove-box box-vm'); ?>>
					<div class="box-inner-p-bigger box-single">

                        <?php if ( $page_options['title'] ) : ?>
                            <?php get_template_part('template-parts/page/entry-header'); ?>
                        <?php endif; ?>

					    <?php get_template_part('template-parts/page/entry-content'); ?>

					</div>
                </article>

            <?php endwhile; ?>

            <?php comments_template(); ?>

        </div>  	

</div>

<?php get_footer(); ?>