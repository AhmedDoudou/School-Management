<?php
/**
 * Template for displaying coming soon countdown
 *
 * @author  ThimPress
 * @version 1.0
 */
?>
<div class="learn-press-coming-soon-course-message message-notice message">
	<?php echo $message; ?>
</div>
