<?php
/**
 * Preload Template: rotated plane
 *
 * @package Thim_Starter_Theme
 */
?>

<div class="sk-rotating-plane"></div>