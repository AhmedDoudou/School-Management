<?php

 return array (
  'system_colors' => 
  array (
    0 => 
    array (
      '_id' => 'vamtam_accent_1',
      'title' => 'Accent 1',
      'color' => '#E74C25',
    ),
    1 => 
    array (
      '_id' => 'vamtam_accent_2',
      'title' => 'Accent 2',
      'color' => '#167287',
    ),
    2 => 
    array (
      '_id' => 'vamtam_accent_3',
      'title' => 'Accent 3',
      'color' => '#0A303A',
    ),
    3 => 
    array (
      '_id' => 'vamtam_accent_4',
      'title' => 'Accent 4',
      'color' => '#D8D8D8',
    ),
    4 => 
    array (
      '_id' => 'vamtam_accent_5',
      'title' => 'Accent 5',
      'color' => '#FFFFFF',
    ),
    5 => 
    array (
      '_id' => 'vamtam_accent_6',
      'title' => 'Accent 6',
      'color' => '#000000',
    ),
    6 => 
    array (
      '_id' => 'vamtam_accent_7',
      'title' => 'Accent 7',
      'color' => '#EDEDED',
    ),
    7 => 
    array (
      '_id' => 'vamtam_accent_8',
      'title' => 'Accent 8',
      'color' => '#F4F1EA',
    ),
    8 => 
    array (
      '_id' => 'vamtam_primary_font_color',
      'title' => 'Primary Font',
      'color' => '#333333',
    ),
    9 => 
    array (
      '_id' => 'vamtam_h1_color',
      'title' => 'H1',
      'color' => '#0A303A',
    ),
    10 => 
    array (
      '_id' => 'vamtam_h2_color',
      'title' => 'H2',
      'color' => '#0A303A',
    ),
    11 => 
    array (
      '_id' => 'vamtam_h3_color',
      'title' => 'H3',
      'color' => '#0A303A',
    ),
    12 => 
    array (
      '_id' => 'vamtam_h4_color',
      'title' => 'H4',
      'color' => '#0A303A',
    ),
    13 => 
    array (
      '_id' => 'vamtam_h5_color',
      'title' => 'H5',
      'color' => '#0A303A',
    ),
    14 => 
    array (
      '_id' => 'vamtam_h6_color',
      'title' => 'H6',
      'color' => '#0A303A',
    ),
    15 => 
    array (
      '_id' => 'vamtam_sticky_header_bg_color',
      'title' => 'Sticky Header Bg Color',
      'color' => '#FFFFFF',
    ),
  ),
  'system_typography' => 
  array (
    0 => 
    array (
      '_id' => 'vamtam_primary_font',
      'title' => 'Primary Font',
      'typography_typography' => 'custom',
      'typography_font_family' => 'Catamaran',
      'typography_font_weight' => 'normal',
      'typography_font_style' => 'normal',
      'typography_text_transform' => 'none',
      'typography_text_decoration' => 'none',
      'typography_font_size' => 
      array (
        'size' => '18',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_tablet' => 
      array (
        'size' => '16',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_mobile' => 
      array (
        'size' => '16',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height' => 
      array (
        'size' => '1.5',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_tablet' => 
      array (
        'size' => '',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_mobile' => 
      array (
        'size' => '',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_tablet' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_mobile' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
    ),
    1 => 
    array (
      '_id' => 'vamtam_h1',
      'title' => 'H1',
      'typography_typography' => 'custom',
      'typography_font_family' => 'Catamaran',
      'typography_font_weight' => '900',
      'typography_font_style' => 'normal',
      'typography_text_transform' => 'none',
      'typography_text_decoration' => 'none',
      'typography_font_size' => 
      array (
        'size' => '60',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_tablet' => 
      array (
        'size' => '50',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_mobile' => 
      array (
        'size' => '44',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height' => 
      array (
        'size' => '1.1',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_tablet' => 
      array (
        'size' => '',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_mobile' => 
      array (
        'size' => '1.1',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_tablet' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_mobile' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
    ),
    2 => 
    array (
      '_id' => 'vamtam_h2',
      'title' => 'H2',
      'typography_typography' => 'custom',
      'typography_font_family' => 'Catamaran',
      'typography_font_weight' => '800',
      'typography_font_style' => 'normal',
      'typography_text_transform' => 'none',
      'typography_text_decoration' => 'none',
      'typography_font_size' => 
      array (
        'size' => '48',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_tablet' => 
      array (
        'size' => '30',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_mobile' => 
      array (
        'size' => '26',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height' => 
      array (
        'size' => '1.1',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_tablet' => 
      array (
        'size' => '1.2',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_mobile' => 
      array (
        'size' => '1.2',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_tablet' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_mobile' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      '_id' => 'vamtam_h3',
      'title' => 'H3',
      'typography_typography' => 'custom',
      'typography_font_family' => 'Catamaran',
      'typography_font_weight' => '900',
      'typography_font_style' => 'normal',
      'typography_text_transform' => 'none',
      'typography_text_decoration' => 'none',
      'typography_font_size' => 
      array (
        'size' => '26',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_tablet' => 
      array (
        'size' => '26',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_mobile' => 
      array (
        'size' => '24',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height' => 
      array (
        'size' => '1.21',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_tablet' => 
      array (
        'size' => '1.21',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_mobile' => 
      array (
        'size' => '1.21',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_tablet' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_mobile' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
    ),
    4 => 
    array (
      '_id' => 'vamtam_h4',
      'title' => 'H4',
      'typography_typography' => 'custom',
      'typography_font_family' => 'Catamaran',
      'typography_font_weight' => '800',
      'typography_font_style' => 'normal',
      'typography_text_transform' => 'none',
      'typography_text_decoration' => 'none',
      'typography_font_size' => 
      array (
        'size' => '20',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_tablet' => 
      array (
        'size' => '18',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_mobile' => 
      array (
        'size' => '16',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height' => 
      array (
        'size' => '1.27',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_tablet' => 
      array (
        'size' => '',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_mobile' => 
      array (
        'size' => '1.27',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_tablet' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_mobile' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
    ),
    5 => 
    array (
      '_id' => 'vamtam_h5',
      'title' => 'H5',
      'typography_typography' => 'custom',
      'typography_font_family' => 'Catamaran',
      'typography_font_weight' => '800',
      'typography_font_style' => 'normal',
      'typography_text_transform' => 'none',
      'typography_text_decoration' => 'none',
      'typography_font_size' => 
      array (
        'size' => '16',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_tablet' => 
      array (
        'size' => '16',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_mobile' => 
      array (
        'size' => '14',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height' => 
      array (
        'size' => '1.5',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_tablet' => 
      array (
        'size' => '',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_mobile' => 
      array (
        'size' => '',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_tablet' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_mobile' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
    ),
    6 => 
    array (
      '_id' => 'vamtam_h6',
      'title' => 'H6',
      'typography_typography' => 'custom',
      'typography_font_family' => 'Catamaran',
      'typography_font_weight' => '600',
      'typography_font_style' => 'normal',
      'typography_text_transform' => 'none',
      'typography_text_decoration' => 'none',
      'typography_font_size' => 
      array (
        'size' => '14',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_tablet' => 
      array (
        'size' => '12',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_font_size_mobile' => 
      array (
        'size' => '12',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height' => 
      array (
        'size' => '1.5',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_tablet' => 
      array (
        'size' => '1.17',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_line_height_mobile' => 
      array (
        'size' => '',
        'unit' => 'em',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_tablet' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
      'typography_letter_spacing_mobile' => 
      array (
        'size' => '',
        'unit' => 'px',
        'sizes' => 
        array (
        ),
      ),
    ),
  ),
);