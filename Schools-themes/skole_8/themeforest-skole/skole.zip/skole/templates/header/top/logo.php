<?php get_template_part( 'templates/header/top/logo', 'wrapper' ) ?>
