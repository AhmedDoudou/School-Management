<div class="post-actions-wrapper">
	<?php get_template_part( 'templates/post/meta/date-small' ) ?>
</div>