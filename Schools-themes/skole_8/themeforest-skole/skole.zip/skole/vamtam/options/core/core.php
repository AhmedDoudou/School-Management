<?php

/**
 * Controls attached to core sections
 *
 * @package vamtam/skole
 */


return array(
	array(
		'label'     => esc_html__( 'Header Logo Type', 'skole' ),
		'id'        => 'header-logo-type',
		'type'      => 'switch',
		'transport' => 'postMessage',
		'section'   => 'title_tagline',
		'choices'   => array(
			'image'      => esc_html__( 'Image', 'skole' ),
			'site-title' => esc_html__( 'Site Title', 'skole' ),
		),
		'priority' => 8,
	),
);


